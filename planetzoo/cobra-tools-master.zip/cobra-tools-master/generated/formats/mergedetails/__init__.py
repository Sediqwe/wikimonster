from generated.formats.mergedetails.imports import name_type_map
