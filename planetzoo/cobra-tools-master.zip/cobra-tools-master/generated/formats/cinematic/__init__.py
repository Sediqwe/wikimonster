from generated.formats.cinematic.imports import name_type_map
