from generated.formats.matcol.imports import name_type_map
