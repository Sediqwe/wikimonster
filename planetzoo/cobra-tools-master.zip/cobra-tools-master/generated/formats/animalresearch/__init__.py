from generated.formats.animalresearch.imports import name_type_map
