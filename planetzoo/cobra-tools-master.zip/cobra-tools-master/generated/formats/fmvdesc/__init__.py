from generated.formats.fmvdesc.imports import name_type_map
