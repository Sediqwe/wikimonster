from generated.formats.motiongraph.imports import name_type_map
