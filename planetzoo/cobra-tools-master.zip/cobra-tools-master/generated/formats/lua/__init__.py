from generated.formats.lua.imports import name_type_map
