from generated.formats.lut.imports import name_type_map
