from generated.formats.fct.imports import name_type_map
