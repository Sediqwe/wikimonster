from generated.formats.logicalcontrols.imports import name_type_map
