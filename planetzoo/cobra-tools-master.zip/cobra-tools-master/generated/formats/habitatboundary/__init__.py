from generated.formats.habitatboundary.imports import name_type_map
