from generated.formats.assetpkg.imports import name_type_map
