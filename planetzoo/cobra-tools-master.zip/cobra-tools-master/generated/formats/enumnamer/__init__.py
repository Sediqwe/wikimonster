from generated.formats.enumnamer.imports import name_type_map
