from generated.formats.island.imports import name_type_map
