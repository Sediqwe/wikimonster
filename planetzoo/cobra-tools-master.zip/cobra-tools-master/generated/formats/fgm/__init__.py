from generated.formats.fgm.imports import name_type_map
