from generated.formats.curve.imports import name_type_map
