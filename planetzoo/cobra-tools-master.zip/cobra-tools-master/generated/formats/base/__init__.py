from generated.formats.base.imports import name_type_map
