from generated.formats.decalsettings.imports import name_type_map
