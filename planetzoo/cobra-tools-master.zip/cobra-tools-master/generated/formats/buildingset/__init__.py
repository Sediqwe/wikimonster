from generated.formats.buildingset.imports import name_type_map
