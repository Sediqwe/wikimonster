from generated.formats.guesteconomy.imports import name_type_map
