# cobra-tools: Experimentals
"~~Life~~ Modding finds a way."

This folder contains experimental scripts that may harm your game files when 
used without knowledge. These files are for testing, reversing and 
discovering and should not be used unless instructed.

Voxelskirt_tool.py: allows modifying an entire layer of the vlx struct with a
					custom value. Can be used to flatten the terrain, 
					remove/add vegetation, paint, alter the playable area and 
					other dressings.

locovl_tool.py:     creates a loc.ovl file from a loc.txt file in csv format.

deps_tool.py:       adds or removes dependecies (forcing the game to load 
					other ovl files) to an ovl.
					