class Method:

    def __init__(self):
        pass

